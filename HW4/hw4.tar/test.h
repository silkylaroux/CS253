#ifndef PARSER
#define PARSER

    std::vector<std::string> parse(std::string str);

    //char check_tag_num(long num);
    //std::string string_from_num(long input);
    std::string print_vector(std::vector<std::string> vec);
    std::string print_uns_vector(std::vector<std::string> vec);
    //void run_serialize(int opt, int args_int, char **args_names);

#endif