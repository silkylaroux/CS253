#ifndef UNSERPARSER
#define UNSERPARSER

    std::vector<std::string> unserial_parse(std::string input);

#endif