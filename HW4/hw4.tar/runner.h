#ifndef RUNNER
#define RUNNER

    std::string run_ser(std::string);
    std::string run_unser(std::string);

#endif