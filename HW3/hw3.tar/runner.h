#ifndef RUNNER
#define RUNNER

    void run_serialize(int opt, int args_int, char **args_names);
    void run_unserialize(int opt, int args_int, char **args_names);

#endif