#ifndef PARSER
#define PARSER

//class test{
    //public:
        std::vector<std::string> parse(std::string str);
//};
        char check_tag_num(long num);
        std::string string_from_num(long input);
        void print_vector(std::vector<std::string> vec);

#endif